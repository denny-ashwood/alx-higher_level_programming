#!/usr/bin/python3
from variable_load_5 import a

if __name__ == "__main__":
    print(a)
