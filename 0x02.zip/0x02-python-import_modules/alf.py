#!/usr/bin/python3

alph = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
